# paginas/formulario.py
from dash import html, dcc
import dash_bootstrap_components as dbc

def create_inputs_card():
    return dbc.Card([
        dbc.CardHeader(html.H5("🔧 Parâmetros de Entrada", className="mb-0")),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.Label("Gastos com Marketing (R$):"),
                    dcc.Input(id='input_marketing', type='number', placeholder="Ex: 25000", value=20000, className="w-100")
                ], width=6),
                dbc.Col([
                    html.Label("Estoque disponível (unidades):"),
                    dcc.Input(id='input_estoque', type='number', placeholder="Ex: 300", value=200, className="w-100")
                ], width=6),
            ], className="mb-3"),

            dbc.Row([
                dbc.Col([
                    html.Label("Região:"),
                    dcc.Dropdown(
                        id='input_regiao',
                        options=[{'label': r, 'value': r} for r in ['Sudeste', 'Sul', 'Nordeste', 'Centro-Oeste', 'Norte']],
                        value='Sudeste'
                    )
                ], width=6),

                dbc.Col([
                    html.Label("Categoria:"),
                    dcc.Dropdown(
                        id='input_categoria',
                        options=[{'label': c, 'value': c} for c in ['Linha Branca', 'Premium', 'Eletroportáteis']],
                        value='Linha Branca'
                    )
                ], width=6),
            ], className="mb-3"),
        ])
    ], className="card-section")
