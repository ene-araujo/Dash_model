# paginas/graficos.py
from dash import html, dcc
import dash_bootstrap_components as dbc
from dash import dash_table

def create_meta_card():
    return dbc.Card([
        dbc.CardHeader(html.H5("🎯 Configuração de Metas", className="mb-0")),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.Label("Tipo de Meta:"),
                    dcc.Dropdown(
                        id='input_tipo_meta',
                        options=[
                            {'label': 'Crescimento Anual (+10%)', 'value': 'anual'},
                            {'label': 'Acompanhamento Periódico', 'value': 'periodico'},
                            {'label': 'Meta Personalizada', 'value': 'personalizada'}
                        ],
                        value='periodico'
                    )
                ], width=6),

                dbc.Col([
                    html.Label("Meta de Vendas (R$):"),
                    dcc.Input(id='input_meta_valor', type='number', placeholder="Ex: 500000", value=500000, className="w-100")
                ], width=6),
            ], className="mb-3"),

            dbc.Row([
                dbc.Col([
                    html.Label("Período de Acompanhamento:"),
                    dcc.Dropdown(
                        id='input_periodo',
                        options=[
                            {'label': 'Mensal', 'value': 'mensal'},
                            {'label': 'Trimestral', 'value': 'trimestral'}
                        ],
                        value='mensal'
                    )
                ], width=6),

                dbc.Col([
                    dbc.Button("Calcular Previsão e Atualizar Gráfico", id='btn_prever', color='primary', className="w-100")
                ], width=6)
            ])
        ])
    ], className="card-section")


def create_result_graph_card():
    return dbc.Card([
        dbc.CardHeader(html.H5("📈 Resultado & Gráfico", className="mb-0")),
        dbc.CardBody([
            html.Div(id='saida_previsao', className="mb-3"),
            dcc.Graph(id='grafico_meta'),
        ])
    ], className="card-section")


def create_table_card(df):
    return dbc.Card([
        dbc.CardHeader(html.H5("📋 Dados Sintéticos (para testes)", className="mb-0")),
        dbc.CardBody([
            dash_table.DataTable(
                id='tabela_sintetica',
                columns=[{"name": i, "id": i} for i in df.columns],
                data=df.to_dict('records'),
                page_size=8,
                row_selectable='single',
                style_table={'overflowX': 'auto'},
                style_cell={'textAlign': 'center'}
            )
        ])
    ], className="card-section")
